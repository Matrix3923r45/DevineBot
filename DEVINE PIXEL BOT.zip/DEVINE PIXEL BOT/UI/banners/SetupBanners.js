const setupBanners = {
    helpBanner : 'https://ibb.co/DFbTYJJ',
    verificationBanner : 'https://i.ibb.co/pjHDXzXx/static.png',
    ticketBanner : 'https://i.ibb.co/h1DBsRnv/ticket.gif',
    autovcBanner : 'https://i.ibb.co/mk6Tj1r/autovc.gif',
};

module.exports = setupBanners;
