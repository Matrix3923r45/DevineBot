
module.exports = {
    enabled: true, 
    lavalink: {
        name: "DevinePixel",
        password: "devinepixy",
        host: "193.226.78.187",
        port:  3543,
        secure: false
    }
};
